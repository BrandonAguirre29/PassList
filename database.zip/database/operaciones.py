import sys
import os
from datetime import datetime, timedelta
from sqlalchemy import text

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.db import get_session
from config.configuracion import (
    MINUTOS_ANTES_CLASE,
    MINUTOS_PRESENTE,
    MINUTOS_RETARDO
)

# ── Configuración ────────────────────────────────────────────────────────────
GRUPO_ACTIVO = 1

# ── MODO PRUEBA ──────────────────────────────────────────────────────────────
# Cambia MODO_PRUEBA a True para simular día y hora
# Cambia a False cuando uses el sistema en producción
MODO_PRUEBA  = True
PRUEBA_DIA   = "Lunes"    # Debe coincidir con DiaSemana en tu tabla Horarios
PRUEBA_HORA  = "07:56:00"  # Debe estar dentro de HoraInicio y HoraFin
# ─────────────────────────────────────────────────────────────────────────────

DIAS = {
    "Monday":    "Lunes",
    "Tuesday":   "Martes",
    "Wednesday": "Miercoles",
    "Thursday":  "Jueves",
    "Friday":    "Viernes",
    "Saturday":  "Sabado",
    "Sunday":    "Domingo"
}


def obtener_horario_activo():
    ahora = datetime.now()

    if MODO_PRUEBA:
        dia_es   = PRUEBA_DIA
        hora_now = PRUEBA_HORA
        print(f"[AttendanceRepo] 🧪 MODO PRUEBA — simulando {dia_es} {hora_now}")
    else:
        dia_es   = DIAS.get(ahora.strftime("%A"))
        hora_now = ahora.strftime("%H:%M:%S")

    # Calcula el rango: desde MINUTOS_ANTES_CLASE antes hasta fin de clase
    fmt      = "%H:%M:%S"
    h_actual = datetime.strptime(hora_now, fmt)
    h_con_anticipacion = (h_actual + timedelta(minutes=MINUTOS_ANTES_CLASE)).strftime(fmt)

    query = text("""
        SELECT HorarioID, HoraInicio
        FROM Horarios
        WHERE DiaSemana  = :dia
          AND HoraInicio <= :hora_anticipada
          AND HoraFin    >= :hora_now
          AND GrupoID    = :grupo
    """)

    with get_session() as session:
        resultado = session.execute(query, {
            "dia":             dia_es,
            "hora_anticipada": h_con_anticipacion,
            "hora_now":        hora_now,
            "grupo":           GRUPO_ACTIVO
        }).fetchone()

    if resultado:
        print(f"[AttendanceRepo] 📅 Horario activo: HorarioID={resultado[0]} | {dia_es} {hora_now}")
        return {"horario_id": resultado[0], "hora_inicio": str(resultado[1])}
    else:
        print(f"[AttendanceRepo] ⚠ No hay clase activa ({dia_es} {hora_now})")
        return None


def obtener_alumno_id(dataset_folder: str) -> int | None:
    query = text("""
        SELECT AlumnoID FROM Alumnos
        WHERE dataset_folder = :folder
    """)

    with get_session() as session:
        resultado = session.execute(query, {"folder": dataset_folder}).fetchone()

    return resultado[0] if resultado else None


def alumno_ya_registrado(alumno_id: int, horario_id: int) -> bool:
    hoy = datetime.now().strftime("%Y-%m-%d")

    query = text("""
        SELECT COUNT(*) FROM Asistencias
        WHERE AlumnoID  = :alumno_id
          AND HorarioID = :horario_id
          AND Fecha     = :fecha
    """)

    with get_session() as session:
        resultado = session.execute(query, {
            "alumno_id":  alumno_id,
            "horario_id": horario_id,
            "fecha":      hoy
        }).scalar()

    return resultado > 0


def registrar_asistencia(dataset_folder: str, horario_id: int, hora_inicio_clase: str) -> bool:
    ahora     = datetime.now()
    alumno_id = obtener_alumno_id(dataset_folder)

    if alumno_id is None:
        print(f"[AttendanceRepo] ⚠ '{dataset_folder}' no encontrado en DB.")
        return False

    if alumno_ya_registrado(alumno_id, horario_id):
        return False

    # Hora real o de prueba
    hora_registro = PRUEBA_HORA if MODO_PRUEBA else ahora.strftime("%H:%M:%S")

    # Calcular estado según tolerancias
    estado = calcular_estado(hora_inicio_clase, hora_registro)

    query = text("""
        INSERT INTO Asistencias (AlumnoID, HorarioID, Fecha, HoraRegistro, Estado)
        VALUES (:alumno_id, :horario_id, :fecha, :hora, :estado)
    """)

    try:
        with get_session() as session:
            session.execute(query, {
                "alumno_id":  alumno_id,
                "horario_id": horario_id,
                "fecha":      ahora.strftime("%Y-%m-%d"),
                "hora":       hora_registro,
                "estado":     estado
            })
            session.commit()
        print(f"[AttendanceRepo] ✅ {estado} — {dataset_folder} registrado.")
        return True
    except Exception as e:
        import traceback
        print(f"[AttendanceRepo] ❌ Error: {e}")
        traceback.print_exc()
        return False
    

def calcular_estado(hora_inicio_clase, hora_registro: str) -> str:
    fmt = "%H:%M:%S"
    
    # Convertir hora_inicio_clase a string sin importar el tipo que venga
    if hasattr(hora_inicio_clase, 'seconds'):
        # Es un timedelta (como lo devuelve SQL Server)
        total = int(hora_inicio_clase.total_seconds())
        h = total // 3600
        m = (total % 3600) // 60
        s = total % 60
        hora_inicio_str = f"{h:02d}:{m:02d}:{s:02d}"
    else:
        hora_inicio_str = str(hora_inicio_clase)[:8]

    h_inicio   = datetime.strptime(hora_inicio_str, fmt)
    h_registro = datetime.strptime(hora_registro[:8], fmt)

    diferencia = (h_registro - h_inicio).total_seconds() / 60

    print(f"[AttendanceRepo] ⏱ Diferencia: {diferencia:.1f} min | límite presente: {MINUTOS_PRESENTE} | límite retardo: {MINUTOS_RETARDO}")

    if diferencia <= MINUTOS_PRESENTE:
        return "PRESENTE"
    elif diferencia <= MINUTOS_RETARDO:
        return "RETARDO"
    else:
        return "FALTA"