"""
database/db.py
--------------
Conexión a SQL Server usando autenticación de Windows.
No requiere usuario ni contraseña.
"""

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

# ── Configuración de conexión ────────────────────────────────────────────────
SERVER   = "localhost"
DATABASE = "PassLi"
DRIVER   = "ODBC+Driver+17+for+SQL+Server"

CONNECTION_STRING = (
    f"mssql+pyodbc://{SERVER}/{DATABASE}"
    f"?driver={DRIVER}"
    f"&trusted_connection=yes"
)

engine       = create_engine(CONNECTION_STRING, echo=False)
SessionLocal = sessionmaker(bind=engine)


def get_session():
    return SessionLocal()


def probar_conexion():
    try:
        with engine.connect() as conn:
            resultado = conn.execute(text("SELECT DB_NAME() AS base_activa"))
            fila = resultado.fetchone()
            print(f"[DB]  Conexión exitosa — Base de datos activa: {fila[0]}")
            return True
    except Exception as e:
        print(f"[DB]  Error de conexión: {e}")
        return False


if __name__ == "__main__":
    probar_conexion()